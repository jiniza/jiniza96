export class Feedback {
    userId:string;
    star:number;
    feedbackMessage:string;
    message:string;
}
