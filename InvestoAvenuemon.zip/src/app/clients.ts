export class Clients {
    userId:string;
    name:string;
    password:string ;
    typeOfClient:string ;
    contactNo:number;
    email :string;
    cdate:Date;
    message:string;
    detail:number;

}
