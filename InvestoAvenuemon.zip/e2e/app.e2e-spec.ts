import { InvestoAvenuePage } from './app.po';

describe('investo-avenue App', () => {
  let page: InvestoAvenuePage;

  beforeEach(() => {
    page = new InvestoAvenuePage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
