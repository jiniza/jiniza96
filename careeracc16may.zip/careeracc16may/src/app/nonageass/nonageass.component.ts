import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { HomeserviceService } from '../home/homeservice.service';
import { GlobalUserNameService } from '../home/global.service';

@Component({
  selector: 'app-nonageass',
  templateUrl: './nonageass.component.html',
  styleUrls: ['./nonageass.component.css']
})
export class NonageassComponent implements OnInit {
  errorMessage:any;
  successMessage:any;
  res:any;
  testForm :FormGroup;
  constructor(private fb: FormBuilder,private HomeserviceService:HomeserviceService,private GlobalUserNameService:GlobalUserNameService) { }

  ngOnInit() {
    this.testForm=this.fb.group({
     
      option1:['',[Validators.required]],
      option2:['',[Validators.required]],
      option3:['',[Validators.required]],
      option4:['',[Validators.required]],
      option5:['',[Validators.required]],
      option6:['',[Validators.required]],
      option7:['',[Validators.required]],
      option8:['',[Validators.required]],
      option9:['',[Validators.required]],
      option10:['',[Validators.required]],
      option11:['',[Validators.required]],
      option12:['',[Validators.required]],
      option13:['',[Validators.required]],
      option14:['',[Validators.required]],
      option15:['',[Validators.required]],
      username:['']  


    });
  }


  setOptions(){   
    console.log("non age assgn")
    this.errorMessage = null
    this.successMessage = null
    this.res = null
    this.testForm.get('username').setValue(this.GlobalUserNameService.getCurrency());
    
    this.HomeserviceService.setOptions(this.testForm.value)
    .then(response=>{this.res=response;})
    .catch(error=>{this.errorMessage=error.message})
  }
  createDelay(){      
    var start = new Date().getTime();      
    var end = start;      
    while(end < start +3000) {      
        end = new Date().getTime();      
    }   }    

}
