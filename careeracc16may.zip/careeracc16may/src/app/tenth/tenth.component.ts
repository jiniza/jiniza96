import { Component, OnInit } from '@angular/core';
import { GlobalUserNameService } from '../home/global.service';

@Component({
  selector: 'app-tenth',
  templateUrl: './tenth.component.html',
  styleUrls: ['./tenth.component.css']
})
export class TenthComponent implements OnInit {

  constructor(private GlobalUserNameService:GlobalUserNameService) { }

  ngOnInit() {
  }
  createDelay(){      
    var start = new Date().getTime();      
    var end = start;      
    while(end < start +3000) {      
        end = new Date().getTime();      
    }   }    

}
