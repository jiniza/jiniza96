import { Component, OnInit } from '@angular/core';
import { HomeserviceService } from '../home/homeservice.service';
import { GlobalUserNameService } from '../home/global.service';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  errorMessage:any;
  successMessage:any;
  res:any;
  logstatus = this.GlobalUserNameService.getLoggedIn();

  constructor(private HomeserviceService:HomeserviceService,private GlobalUserNameService:GlobalUserNameService,private auth:AuthService) { }

  ngOnInit() {
  }

  displayProfile(){   
    this.errorMessage = null
    this.successMessage = null
    this.res = null
    this.GlobalUserNameService.setLoggedIn(false);
    this.HomeserviceService.profile(this.GlobalUserNameService.getCurrency())
    .then(response=>{this.res=response;})
    .catch(error=>{this.errorMessage=error.message})
     
  }


}
