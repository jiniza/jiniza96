import { Component, OnInit } from '@angular/core';
import { GlobalUserNameService } from '../home/global.service';
import { HomeserviceService } from '../home/homeservice.service';
import { Window } from 'selenium-webdriver';
import {Chart} from "chart.js";

@Component({
  selector: 'app-reportscreen',
  templateUrl: './reportscreen.component.html',
  styleUrls: ['./reportscreen.component.css']
})
export class ReportscreenComponent implements OnInit {
  errorMessage:any;
  successMessage:any;
  a: boolean=true;
  res:any;
 

  constructor(private HomeserviceService:HomeserviceService,private GlobalUserNameService:GlobalUserNameService) { }

  ngOnInit() {
  

  }

  displayReport(){   
    this.errorMessage = null
    this.successMessage = null
    this.res = null
    console.log("qwewrerqw")
    this.HomeserviceService.report(this.GlobalUserNameService.getCurrency())
    .then(response=>this.res=response)
    .then(response=>this.successMessage=response.message)
    .catch(error=>{this.errorMessage=error.message})  
    
    
  }
  print()
  {
    
    window.print();
     
  }

}
