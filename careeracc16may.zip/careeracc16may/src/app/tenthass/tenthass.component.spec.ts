import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TenthassComponent } from './tenthass.component';

describe('TenthassComponent', () => {
  let component: TenthassComponent;
  let fixture: ComponentFixture<TenthassComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TenthassComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TenthassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
