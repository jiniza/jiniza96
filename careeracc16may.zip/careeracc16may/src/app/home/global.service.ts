import { Injectable, Directive } from '@angular/core';

@Injectable()
export class GlobalUserNameService {
    private us: string;
    private standard:string;
    private loggedIn:string;
  
    constructor() { }

    setCurrency(val) {
        this.us = val;
    }

    getCurrency() {
        return this.us;
    }

    setStandard(val) {
        this.standard = val;
    }

    getStandard() {
        return this.standard;
    }

    setLoggedIn(val) {
        this.loggedIn = val;
    }

    getLoggedIn() {
        return this.loggedIn;
    }
    
  }