import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { HomeserviceService } from './homeservice.service';
import { AbstractControl } from '@angular/forms/src/model';
import { ValidationErrors } from '@angular/forms/src/directives/validators';
import { SignupComponent } from './signup/signup.component';
import { GlobalUserNameService } from './global.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { ProfileComponent } from '../profile/profile.component';



@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  
registrationForm :FormGroup;
successMessage:string;
   errorMessage:string;
   private myRoute:Router;
   result:any;
   abc:any;
  constructor(private fb: FormBuilder,public HomeserviceService:HomeserviceService,private GlobalUserNameService:GlobalUserNameService,private auth:AuthService,private router: Router,) { 
    
 
  }

  ngOnInit() {
    this.registrationForm=this.fb.group({
      username:['',[Validators.required,Validators.pattern("^[a-zA-Z0-9]{4,}")]],
      password:['',[Validators.required,Validators.pattern("^.*(?=.{8,})(?=..*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$")]],
      email:['',[Validators.required,Validators.pattern("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$")]]   
    });
    
  } 

 
  
  login(){   
    
    this.errorMessage = null
    this.successMessage = null
    this.result = null
    this.GlobalUserNameService.setLoggedIn(true);
    
    this.HomeserviceService.login(this.registrationForm.value)
    .then(response=>{this.router.navigateByUrl('/profile');
    this.auth.sendToken(this.registrationForm.value)
    this.abc = this.registrationForm.controls.username.value;
    this.GlobalUserNameService.setCurrency(this.abc);
    
    this.GlobalUserNameService.setStandard(response.standard)
  })
    .catch(error=>{this.errorMessage=error.message})
  }
  

  signup() {  
    // console.log("bgvfcv") 
    this.errorMessage = null
    this.successMessage = null
    this.result = null
    this.GlobalUserNameService.setLoggedIn(true);
   
    this.HomeserviceService.signup(this.registrationForm.value)
    .then(response=>{this.result=response;

    this.router.navigateByUrl('/signup');
    this.auth.sendToken(this.registrationForm.value)
    })
    .catch(error=>{this.errorMessage=error.message})  
    this.abc = this.registrationForm.controls.username.value;
    //this.retr()
    this.GlobalUserNameService.setCurrency(this.abc);
    
    
    
}
 

  
    
}




