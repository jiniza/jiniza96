import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import {HttpClient} from '@angular/common/http';
import { GlobalUserNameService } from './global.service';






@Injectable()
export class HomeserviceService {

  constructor(private http: Http,private GlobalUserNameService:GlobalUserNameService) { }

  login(data):Promise<any>{
    console.log(data)
    
    return this.http.post('http://localhost:8765/Career_Accelerate/CareerAPI/getDetails',data)
    .toPromise()
    .then(response => response.json())

    .catch(error => Promise.reject(error.json()))

    
    
  }

  signup(data):Promise<any>{
    console.log("signup"+data.email)
    return this.http.post('http://localhost:8765/Career_Accelerate/CareerAPI/register',data)
    .toPromise()
    .then(response => response.json())
    .catch(error => Promise.reject(error.json()))
  }

  signupuname(data):Promise<any>{
    console.log("signupname"+data.firstName)
    return this.http.post('http://localhost:8765/Career_Accelerate/CareerAPI/registerProfile',data)
    .toPromise()
    .then(response => response.json())
    .catch(error => Promise.reject(error.json()))

  }
  profile(data):Promise<any>{
  
    console.log("profile fn"+data)
    return this.http.get('http://localhost:8765/Career_Accelerate/CareerAPI/getProfile',{params:{username:""+data}})
    .toPromise()
    .then(response => response.json())
    .catch(error => Promise.reject(error.json()))
  }

  setOptions(data):Promise<any>{
  
    console.log("options fn"+data)
    return this.http.post('http://localhost:8765/Career_Accelerate/CareerAPI/setOptions',data)
    .toPromise()
    .then(response => response.json())
    .catch(error => Promise.reject(error.json()))
  }

  report(data):Promise<any>{
  
    console.log("report fn"+data)
    return this.http.get('http://localhost:8765/Career_Accelerate/CareerAPI/evaluate',{params:{username:""+data}})
    .toPromise()
    .then(response => response.json())
    .catch(error => Promise.reject(error.json()))
  }


}
