import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

import { Input } from '@angular/core/src/metadata/directives';
import { HomeComponent } from '../home.component';
import { GlobalUserNameService } from '../global.service';
import { HomeserviceService } from '../homeservice.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
 
  result:any;
  res:any;
  successMessage:string;
   errorMessage:string;
  signUpForm :FormGroup;
  user: string

  constructor(private fb: FormBuilder,private homeComponent: HomeComponent,private GlobalUserNameService:GlobalUserNameService,private HomeserviceService:HomeserviceService) { }

  ngOnInit() {
    
    this.signUpForm=this.fb.group({
      firstName:['',[Validators.required,Validators.pattern("[A-Za-z]{3,}")]],
      lastName:['',[Validators.required,Validators.pattern("[A-Za-z]{3,}")]],
      stream:['',[Validators.required]],
      standard:['',[Validators.required]],
      schoolName:['',[Validators.required,Validators.pattern("^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$")]],
      phoneNumber:['',[Validators.required,Validators.pattern("[0-9]{10}")]],
      username:['']
    });
    // this.user=this.homeComponent.retr();
}
  

 signupdata() {
  
   this.signUpForm.get('username').setValue(this.GlobalUserNameService.getCurrency());
   this.GlobalUserNameService.setStandard(this.signUpForm.get('standard').value)
   console.log("from signup comp" + this.GlobalUserNameService.getStandard())
 
  this.HomeserviceService.signupuname(this.signUpForm.value)
  .then(response=>{this.result=response;})
  .catch(error=>{this.errorMessage=error.message})  
  
  //this.retr()
  }
    }
