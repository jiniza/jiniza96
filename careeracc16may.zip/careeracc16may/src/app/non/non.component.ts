import { Component, OnInit } from '@angular/core';
import { GlobalUserNameService } from '../home/global.service';

@Component({
  selector: 'app-non',
  templateUrl: './non.component.html',
  styleUrls: ['./non.component.css']
})
export class NonComponent implements OnInit {

  constructor(private GlobalUserNameService:GlobalUserNameService) { }

  ngOnInit() {
  }
  createDelay(){      
    var start = new Date().getTime();      
    var end = start;      
    while(end < start +3000) {      
        end = new Date().getTime();      
    }   } 

}
