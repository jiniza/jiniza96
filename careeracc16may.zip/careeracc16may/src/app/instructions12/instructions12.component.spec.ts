import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Instructions12Component } from './instructions12.component';

describe('Instructions12Component', () => {
  let component: Instructions12Component;
  let fixture: ComponentFixture<Instructions12Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Instructions12Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Instructions12Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
