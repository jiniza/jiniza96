import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-instructions12',
  templateUrl: './instructions12.component.html',
  styleUrls: ['./instructions12.component.css']
})
export class Instructions12Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  createDelay(){      
    var start = new Date().getTime();      
    var end = start;      
    while(end < start +3000) {      
        end = new Date().getTime();      
    }   }    

}
