import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';


import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AppRoutingModule } from '../app-routing.module';

import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { TeamComponent } from './team/team.component';
import { TenthComponent } from './tenth/tenth.component';
import { TwelfthComponent } from './twelfth/twelfth.component';
import { NonComponent } from './non/non.component';
import { HomeserviceService } from './home/homeservice.service';
import { ContactComponent } from './home/contact/contact.component';

import { CareerComponent } from './career/career.component';
import { SuccessComponent } from './home/success/success.component';
import { ProfileComponent } from './profile/profile.component';
import { SignupComponent } from './home/signup/signup.component';
import { GlobalUserNameService } from './home/global.service';

import {HttpClientModule} from '@angular/common/http';
import { AuthService } from './auth.service';
import { AuthGuard } from './auth.guard';
import { RouterModule } from '@angular/router/src/router_module';
import { TenthassComponent } from './tenthass/tenthass.component';
import { TwelassComponent } from './twelass/twelass.component';
import { NonageassComponent } from './nonageass/nonageass.component';
import { ReportscreenComponent } from './reportscreen/reportscreen.component';
import { InstructionsComponent } from './instructions/instructions.component';
import { Instructions12Component } from './instructions12/instructions12.component';
import { InstructionsnonComponent } from './instructionsnon/instructionsnon.component';








// import { TenthComponent } from '../src/app/tenth/tenth.component';
// import { TwelfthComponent } from '../src/app/twelfth/twelfth.component';
// import { NonComponent } from '../src/app/non/non.component';


//import { AboutusComponent } from '/aboutus/aboutus.AboutusComponent';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutusComponent,
    SignupComponent,
    TeamComponent,
    TenthComponent,
    TwelfthComponent,
    NonComponent,
    ContactComponent,
    SuccessComponent,
    CareerComponent,
    ProfileComponent,
    TenthassComponent,
    TwelassComponent,
    NonageassComponent,
    ReportscreenComponent,
    InstructionsComponent,
    Instructions12Component,
    InstructionsnonComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpModule,
    HttpClientModule,
   

    
    
  ],
  providers: [HomeserviceService,HomeComponent,GlobalUserNameService,AuthService,AuthGuard,ProfileComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
