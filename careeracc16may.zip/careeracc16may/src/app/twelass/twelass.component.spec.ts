import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TwelassComponent } from './twelass.component';

describe('TwelassComponent', () => {
  let component: TwelassComponent;
  let fixture: ComponentFixture<TwelassComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TwelassComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TwelassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
