import { Component, OnInit } from '@angular/core';
import { GlobalUserNameService } from '../home/global.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HomeserviceService } from '../home/homeservice.service';

@Component({
  selector: 'app-twelass',
  templateUrl: './twelass.component.html',
  styleUrls: ['./twelass.component.css']
})
export class TwelassComponent implements OnInit {
  errorMessage:any;
  successMessage:any;
  res:any;
  testForm :FormGroup;

  constructor(private fb: FormBuilder,private HomeserviceService:HomeserviceService,private GlobalUserNameService:GlobalUserNameService) { }

  ngOnInit() {
    this.testForm=this.fb.group({
     
      option1:['',[Validators.required]],
      option2:['',[Validators.required]],
      option3:['',[Validators.required]],
      option4:['',[Validators.required]],
      option5:['',[Validators.required]],
      option6:['',[Validators.required]],
      option7:['',[Validators.required]],
      option8:['',[Validators.required]],
      option9:['',[Validators.required]],
      option10:['',[Validators.required]],
      option11:['',[Validators.required]],
      option12:['',[Validators.required]],
      option13:['',[Validators.required]],
      option14:['',[Validators.required]],
      option15:['',[Validators.required]],
      username:['']  
  });
}
setOptions(){   
  this.errorMessage = null
  this.successMessage = null
  this.res = null
  this.testForm.get('username').setValue(this.GlobalUserNameService.getCurrency());
  
  this.HomeserviceService.setOptions(this.testForm.value)
  .then(response=>{this.res=response;})
  .catch(error=>{this.errorMessage=error.message})
}

createDelay(){      
  var start = new Date().getTime();      
  var end = start;      
  while(end < start +3000) {      
      end = new Date().getTime();      
  }   }    

}
