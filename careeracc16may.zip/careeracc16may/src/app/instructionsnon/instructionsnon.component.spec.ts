import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InstructionsnonComponent } from './instructionsnon.component';

describe('InstructionsnonComponent', () => {
  let component: InstructionsnonComponent;
  let fixture: ComponentFixture<InstructionsnonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InstructionsnonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InstructionsnonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
