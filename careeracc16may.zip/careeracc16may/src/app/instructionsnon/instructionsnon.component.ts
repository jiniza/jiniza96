import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-instructionsnon',
  templateUrl: './instructionsnon.component.html',
  styleUrls: ['./instructionsnon.component.css']
})
export class InstructionsnonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  createDelay(){      
    var start = new Date().getTime();      
    var end = start;      
    while(end < start +3000) {      
        end = new Date().getTime();      
    }   }    

}
