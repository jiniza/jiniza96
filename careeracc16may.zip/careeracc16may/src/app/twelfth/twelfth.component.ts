import { Component, OnInit } from '@angular/core';
import { GlobalUserNameService } from '../home/global.service';

@Component({
  selector: 'app-twelfth',
  templateUrl: './twelfth.component.html',
  styleUrls: ['./twelfth.component.css']
})
export class TwelfthComponent implements OnInit {

  constructor(private GlobalUserNameService:GlobalUserNameService) { }

  ngOnInit() {
  }
  createDelay(){      
    var start = new Date().getTime();      
    var end = start;      
    while(end < start +3000) {      
        end = new Date().getTime();      
    }   } 

}
