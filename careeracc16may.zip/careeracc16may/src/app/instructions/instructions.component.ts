import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-instructions',
  templateUrl: './instructions.component.html',
  styleUrls: ['./instructions.component.css']
})
export class InstructionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  createDelay(){      
    var start = new Date().getTime();      
    var end = start;      
    while(end < start +3000) {      
        end = new Date().getTime();      
    }   }    

}
