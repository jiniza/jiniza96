import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutusComponent } from './app/aboutus/aboutus.component';
import { HomeComponent } from './app/home/home.component';

import { TeamComponent } from './app/team/team.component';
import { TenthComponent } from './app/tenth/tenth.component';
import { TwelfthComponent } from './app/twelfth/twelfth.component';
import { NonComponent } from './app/non/non.component';
import { ContactComponent } from './app/home/contact/contact.component';
import { CareerComponent } from './app/career/career.component';
import { SuccessComponent } from './app/home/success/success.component';
import { ProfileComponent } from './app/profile/profile.component';
import { SignupComponent } from './app/home/signup/signup.component';
import { AuthGuard } from './app/auth.guard';
import { TenthassComponent } from './app/tenthass/tenthass.component';
import { TwelassComponent } from './app/twelass/twelass.component';
import { NonageassComponent } from './app/nonageass/nonageass.component';
import { ReportscreenComponent } from './app/reportscreen/reportscreen.component';
import { InstructionsComponent } from './app/instructions/instructions.component';
import { Instructions12Component } from './app/instructions12/instructions12.component';
import { InstructionsnonComponent } from './app/instructionsnon/instructionsnon.component';



const routes: Routes = [
 { path:'about',component:AboutusComponent },
 {path:'home',component:HomeComponent},
 {path:'signup',component: SignupComponent,canActivate: [AuthGuard]},
 {path:'team',component: TeamComponent},
 {path:'tenth',component: TenthComponent},
 {path:'twelfth',component: TwelfthComponent},
 {path:'non',component: NonComponent},
 {path:'contactus',component: ContactComponent},
 {path:'career',component: CareerComponent},
 {path:'successstory',component: SuccessComponent},
 {path:'profile',component: ProfileComponent,canActivate: [AuthGuard]},
 {path:'ass1',component:TenthassComponent,canActivate: [AuthGuard]},
 {path:'ass2',component:TwelassComponent,canActivate: [AuthGuard]},
 {path:'ass3',component:NonageassComponent,canActivate: [AuthGuard]},
 {path:'reportscreen',component: ReportscreenComponent,canActivate: [AuthGuard]},
 {path:'instr',component: ProfileComponent,canActivate: [AuthGuard]},
 {path:'instruction10',component: InstructionsComponent},
 {path:'instruction12',component: Instructions12Component},
 {path:'instructionnon',component: InstructionsnonComponent},
 

 




];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
