package com.infy.api;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.Exam10;
import com.infy.model.Login;
import com.infy.model.Profile;
import com.infy.service.CareerService;
import com.infy.service.CareerServiceImpl;
import com.infy.utility.ContextFactory;
@RestController
@CrossOrigin
@RequestMapping(value="CareerAPI")
public class CareerAPI {
	private CareerService service;
	
	@RequestMapping(method=RequestMethod.POST, value="getDetails")
	public ResponseEntity<Login> getDetails(@RequestBody Login login){
		Environment environment= ContextFactory.getContext().getEnvironment();
		
		service =  ContextFactory.getContext().getBean(CareerServiceImpl.class);
		
		ResponseEntity<Login> responseEntity;
		try {
			Login login1 = service.getDetails(login);
			responseEntity = new ResponseEntity<Login>(login1,HttpStatus.OK);

		}

		catch(Exception exception) {
			String errorMessage = environment.getProperty(exception.getMessage());
			Login fb = new Login();
			fb.setMessage(errorMessage);
			responseEntity = new ResponseEntity<Login>(fb,HttpStatus.BAD_REQUEST);
}
		return responseEntity;
	}
	@RequestMapping(method=RequestMethod.POST, value="register")
	public ResponseEntity<Login> register(@RequestBody Login login){

		Environment environment= ContextFactory.getContext().getEnvironment();
		
		service =  ContextFactory.getContext().getBean(CareerServiceImpl.class);
		
		ResponseEntity<Login> responseEntity;
		try {
			Login login1 = service.register(login);
			login1.setMessage(environment.getProperty("CareerAPI.SUCCESSFULL"));
			responseEntity = new ResponseEntity<Login>(login1,HttpStatus.OK);

		}

		catch(Exception exception) {
			String errorMessage = environment.getProperty(exception.getMessage());
			Login fb = new Login();
			fb.setMessage(errorMessage);
			responseEntity = new ResponseEntity<Login>(fb,HttpStatus.BAD_REQUEST);

		}

		return responseEntity;

	}
	@RequestMapping(method=RequestMethod.POST, value="registerProfile")
	public ResponseEntity<Profile> registerProfile(@RequestBody Profile profile){

		Environment environment= ContextFactory.getContext().getEnvironment();
		
		service =  ContextFactory.getContext().getBean(CareerServiceImpl.class);
		
		ResponseEntity<Profile> responseEntity;
		try {
			Profile profile1 = service.register(profile);
			profile1.setMessage(environment.getProperty("CareerAPI.SUCCESSFULL"));
			responseEntity = new ResponseEntity<Profile>(profile1,HttpStatus.OK);

		}

		catch(Exception exception) {
			String errorMessage = environment.getProperty(exception.getMessage());
			Profile fb = new Profile();
			fb.setMessage(errorMessage);
			responseEntity = new ResponseEntity<Profile>(fb,HttpStatus.BAD_REQUEST);

		}

		return responseEntity;

	}
	@RequestMapping(method=RequestMethod.GET, value="getProfile")
	public ResponseEntity<Profile> getProfile(@RequestParam String username){
		Environment environment= ContextFactory.getContext().getEnvironment();
		
		service =  ContextFactory.getContext().getBean(CareerServiceImpl.class);
		
		ResponseEntity<Profile> responseEntity;
		try {
			Profile profile = service.getProfile(username);
			responseEntity = new ResponseEntity<Profile>(profile,HttpStatus.OK);

		}

		catch(Exception exception) {
			String errorMessage = environment.getProperty(exception.getMessage());
			Profile fb = new Profile();
			fb.setMessage(errorMessage);
			responseEntity = new ResponseEntity<Profile>(fb,HttpStatus.BAD_REQUEST);
}
		return responseEntity;
	}
	@RequestMapping(method=RequestMethod.POST, value="setOptions")
	public ResponseEntity<Exam10> setOptions(@RequestBody Exam10 exam10){

		Environment environment= ContextFactory.getContext().getEnvironment();
		
		service =  ContextFactory.getContext().getBean(CareerServiceImpl.class);
		
		ResponseEntity<Exam10> responseEntity;
		try {
			Exam10 exam1 = service.setOptions(exam10);
			exam1.setMessage(environment.getProperty("CareerAPI.SUCCESSFULL"));
			responseEntity = new ResponseEntity<Exam10>(exam1,HttpStatus.OK);

		}

		catch(Exception exception) {
			String errorMessage = environment.getProperty(exception.getMessage());
			Exam10 fb = new Exam10();
			fb.setMessage(errorMessage);
			responseEntity = new ResponseEntity<Exam10>(fb,HttpStatus.BAD_REQUEST);

		}

		return responseEntity;

	}
	@RequestMapping(method=RequestMethod.GET, value="evaluate")
	public ResponseEntity<Exam10> evaluate(@RequestParam String username){

		Environment environment= ContextFactory.getContext().getEnvironment();
		
		service =  ContextFactory.getContext().getBean(CareerServiceImpl.class);
		
		ResponseEntity<Exam10> responseEntity;
		try {
			Exam10 exam1 = service.evaluate10(username);
			responseEntity = new ResponseEntity<Exam10>(exam1,HttpStatus.OK);
		}

		catch(Exception exception) {
			String errorMessage = environment.getProperty(exception.getMessage());
			Exam10 fb = new Exam10();
			fb.setMessage(errorMessage);
			responseEntity = new ResponseEntity<Exam10>(fb,HttpStatus.BAD_REQUEST);

		}

		return responseEntity;

	}
	}
