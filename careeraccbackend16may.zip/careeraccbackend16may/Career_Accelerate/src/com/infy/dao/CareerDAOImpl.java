package com.infy.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.Exam10Entity;
import com.infy.entity.LoginEntity;
import com.infy.entity.ProfileEntity;
import com.infy.model.Exam10;
import com.infy.model.Login;import com.infy.model.Profile;
@Repository("dao")
public class CareerDAOImpl implements CareerDAO {
	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public Login getDetails(Login login) {
		Session session = sessionFactory.getCurrentSession();
		LoginEntity loginEntity = session.get(LoginEntity.class,login.getUsername());
		ProfileEntity profileEntity = (ProfileEntity) session.load(ProfileEntity.class,login.getUsername());
		if(	loginEntity !=null && loginEntity.getPassword().equals(login.getPassword())) {
			Login login1 = new Login();
			login1.setUsername(loginEntity.getUsername());
			login1.setPassword(loginEntity.getPassword());
			login1.setEmail(loginEntity.getEmail());
			login1.setStandard(profileEntity.getStandard());
			return login1;
		}
		return null;
	}

	@Override
	public Login register(Login login) {
		Session session = sessionFactory.getCurrentSession();
		Exam10Entity exam=new Exam10Entity();
		ProfileEntity profileEntity=new ProfileEntity();
		LoginEntity loginEntity = new LoginEntity();
			exam.setUsername(login.getUsername());
			loginEntity.setUsername(login.getUsername());
			loginEntity.setPassword(login.getPassword());
			loginEntity.setEmail(login.getEmail());
			profileEntity.setUsername(login.getUsername());
			session.persist(loginEntity);
			session.persist(profileEntity);
			session.persist(exam);
			return login;
	}

	@Override
	public Profile registerProfile(Profile profile) {
		Session session = sessionFactory.getCurrentSession();
		ProfileEntity profileEntity = (ProfileEntity) session.load(ProfileEntity.class,profile.getUsername());
		if(profileEntity!=null){
		profileEntity.setFirstName(profile.getFirstName());
		profileEntity.setLastName(profile.getLastName());
		profileEntity.setStream(profile.getStream());
		profileEntity.setStandard(profile.getStandard());
		profileEntity.setSchoolName(profile.getSchoolName());
		profileEntity.setPhoneNumber(profile.getPhoneNumber());
		session.persist(profileEntity);}
		return profile;
	}

	@Override
	public Profile getProfile(String username) {
		Session session = sessionFactory.getCurrentSession();
		ProfileEntity profileEntity = session.get(ProfileEntity.class,username);
		if(	profileEntity !=null) {
			Profile profile = new Profile();
			profile.setFirstName(profileEntity.getFirstName());
			profile.setLastName(profileEntity.getLastName());
			profile.setStream(profileEntity.getStream());
			profile.setStandard(profileEntity.getStandard());
			profile.setSchoolName(profileEntity.getSchoolName());
			profile.setPhoneNumber(profileEntity.getPhoneNumber());
			return profile;
	}
		return null;}

	@Override
	public Exam10 setOptions(Exam10 exam10) {
		Session session = sessionFactory.getCurrentSession();
		Exam10Entity exam10entity=session.get(Exam10Entity.class,exam10.getUsername());
		exam10entity.setOption1(exam10.getOption1());
		exam10entity.setOption2(exam10.getOption2());
		exam10entity.setOption3(exam10.getOption3());
		exam10entity.setOption4(exam10.getOption4());
		exam10entity.setOption5(exam10.getOption5());
		exam10entity.setOption6(exam10.getOption6());
		exam10entity.setOption7(exam10.getOption7());
		exam10entity.setOption8(exam10.getOption8());
		exam10entity.setOption9(exam10.getOption9());
		exam10entity.setOption10(exam10.getOption10());
		exam10entity.setOption11(exam10.getOption11());
		exam10entity.setOption12(exam10.getOption12());
		exam10entity.setOption13(exam10.getOption13());
		exam10entity.setOption14(exam10.getOption14());
		exam10entity.setOption15(exam10.getOption15());
		session.persist(exam10entity);
		return exam10;
	}

	@Override
	public Exam10 evaluate10(String username) {
		Exam10 exam10=new Exam10();
		int apt=0,gen=0;
		Session session = sessionFactory.getCurrentSession();
		Exam10Entity exam10entity=session.get(Exam10Entity.class,username);
		if(exam10entity.getOption6().equals("2"))
			apt++;
		if(exam10entity.getOption7().equals("3"))
			apt++;
		if(exam10entity.getOption8().equals("3"))
			apt++;
		if(exam10entity.getOption9().equals("1"))
			apt++;
		if(exam10entity.getOption10().equals("2"))
			gen++;
		if(exam10entity.getOption11().equals("2"))
			gen++;
		if(exam10entity.getOption12().equals("1"))
			gen++;
		if(exam10entity.getOption13().equals("3"))
			gen++;
		if(exam10entity.getOption14().equals("2"))
			gen++;
		if(exam10entity.getOption15().equals("3"))
			gen++;
		exam10entity.setVar1((100/4)*apt);
		exam10entity.setVar2((100*gen)/6);
		session.persist(exam10entity);
		exam10.setVar1(exam10entity.getVar1());
		exam10.setVar2(exam10entity.getVar2());
		if(exam10entity.getOption1().equals("literature") && gen>=2)
			return this.literature(exam10entity);
		if(exam10entity.getOption1().equals("art") && gen>=2)
			return this.artist(exam10entity);
		if(exam10entity.getOption1().equals("biology") && apt>=2 && gen>=1)
			return this.medicine(exam10entity);
		if(exam10entity.getOption1().equals("math")||exam10entity.getOption1().equals("computer") && apt>=2 && gen>=1)
			return this.engineering(exam10entity);
		exam10.setVar3(10);
		exam10.setMessage("Can't find a career for you. Sorry, your score is less than the required score. You should improve upon required areas and then attempt the Ideal Career Test again.");
		return exam10;
	}
	public Exam10 evaluate12(String username) {
		Exam10 exam10=new Exam10();
		int log=0,vis=0;
		Session session = sessionFactory.getCurrentSession();
		Exam10Entity exam10entity=session.get(Exam10Entity.class,username);
		if(exam10entity.getOption6().equals("1"))
			log++;
		if(exam10entity.getOption7().equals("1"))
			log++;
		if(exam10entity.getOption8().equals("3"))
			log++;
		if(exam10entity.getOption9().equals("1"))
			log++;
		if(exam10entity.getOption10().equals("2"))
			log++;
		if(exam10entity.getOption11().equals("1"))
			vis++;
		if(exam10entity.getOption12().equals("3"))
			vis++;
		if(exam10entity.getOption13().equals("2"))
			vis++;
		if(exam10entity.getOption14().equals("3"))
			vis++;
		if(exam10entity.getOption15().equals("3"))
			vis++;
		exam10entity.setVar1((100/5)*log);
		exam10entity.setVar2((100/5)*vis);
		session.persist(exam10entity);
		exam10.setVar1(exam10entity.getVar1());
		exam10.setVar2(exam10entity.getVar2());
		if(exam10entity.getOption1().equals("literature") && vis>=2 && log>=2)
			return this.literature(exam10entity);
		if(exam10entity.getOption1().equals("art") && vis>=2 && log>=2)
			return this.artist(exam10entity);
		if(exam10entity.getOption1().equals("biology") && vis>=3 && log>=3)
			return this.engineering(exam10entity);
		if(exam10entity.getOption1().equals("math")||exam10entity.getOption1().equals("computer") && vis>=3 && log>=3)
			return this.engineering(exam10entity);
		exam10.setVar3(10);
		exam10.setMessage("Can't find a career for you. Sorry, your score is less than the required score. You should improve upon required areas and then attempt the Ideal Career Test again.");
		return exam10;
	}

	public Exam10 evaluateNon(String username) {
		Exam10 exam10=new Exam10();
		int log=0,imp=0;
		Session session = sessionFactory.getCurrentSession();
		Exam10Entity exam10entity=session.get(Exam10Entity.class,username);
		if(exam10entity.getOption6().equals("2") ||exam10entity.getOption6().equals("3"))
			imp++;
		if(exam10entity.getOption7().equals("2") || exam10entity.getOption7().equals("3"))
			imp++;
		if(exam10entity.getOption8().equals("2"))
			log++;
		if(exam10entity.getOption9().equals("2"))
			log++;
		if(exam10entity.getOption10().equals("1"))
			log++;
		if(exam10entity.getOption11().equals("1"))
			log++;
		if(exam10entity.getOption12().equals("3"))
			log++;
		if(exam10entity.getOption13().equals("3"))
			log++;
		if(exam10entity.getOption14().equals("2"))
			log++;
		if(exam10entity.getOption15().equals("2"))
			log++;
		exam10entity.setVar1((100/8)*log);
		exam10entity.setVar2((100/2)*imp);
		session.persist(exam10entity);
		exam10.setVar1(exam10entity.getVar1());
		exam10.setVar2(exam10entity.getVar2());
		if(exam10entity.getOption1().equals("literature") && imp>=1 && log>=2)
			return this.literature(exam10entity);
		if(exam10entity.getOption1().equals("art") && imp>=1 && log>=2)
			return this.artist(exam10entity);
		if(exam10entity.getOption1().equals("biology") && imp>=2 && log>=4)
			return this.engineering(exam10entity);
		if(exam10entity.getOption1().equals("math") && imp>=1  && log>=3)
			return this.engineering(exam10entity);
		exam10.setVar3(10);
		exam10.setMessage("Can't find a career for you. Sorry, your score is less than the required score. You should improve upon required areas and then attempt the Ideal Career Test again.");
		return exam10;
	}
	@Override
	public Exam10 literature(Exam10Entity exam10entity) {
		Exam10 exam10=new Exam10();
		int p=3;
		Session session = sessionFactory.getCurrentSession();
		if(exam10entity.getOption2().equals("2")||exam10entity.getOption2().equals("4")){
			p++;
			exam10entity.setVar3((100/5)*p);
			session.persist(exam10entity);
			exam10.setVar1(exam10entity.getVar1());
			exam10.setVar2(exam10entity.getVar2());
			exam10.setVar3(exam10entity.getVar3());
			if(exam10entity.getOption3().equals("2")||exam10entity.getOption3().equals("3")){
				p++;
				exam10.setMessage("Writer! Become a writer! You have a skill for language, your imagination is vast, your brain is overflowing with ideas.");
				exam10entity.setVar3((100/5)*p);
				session.persist(exam10entity);
				exam10.setVar1(exam10entity.getVar1());
				exam10.setVar2(exam10entity.getVar2());
				exam10.setVar3(exam10entity.getVar3());
				return exam10;}}
		exam10entity.setVar3((100/5)*p);
		session.persist(exam10entity);
		exam10.setVar1(exam10entity.getVar1());
		exam10.setVar2(exam10entity.getVar2());
		exam10.setVar3(exam10entity.getVar3());
		exam10.setMessage("Can\'t find a career for you. Sorry!");
		return exam10;
	}

	@Override
	public Exam10 medicine(Exam10Entity exam10entity) {
		Exam10 exam10=new Exam10();
		int p=2;
		Session session = sessionFactory.getCurrentSession();
		if(exam10entity.getOption2().equals("1")||exam10entity.getOption2().equals("4")){
			p++;
			exam10entity.setVar3((100/5)*p);
			session.persist(exam10entity);
			exam10.setVar1(exam10entity.getVar1());
			exam10.setVar2(exam10entity.getVar2());
			exam10.setVar3(exam10entity.getVar3());
			if(exam10entity.getOption4().equals("1")||exam10entity.getOption4().equals("2")){
				p++;
				exam10entity.setVar3((100/5)*p);
				session.persist(exam10entity);
				exam10.setVar1(exam10entity.getVar1());
				exam10.setVar2(exam10entity.getVar2());
				exam10.setVar3(exam10entity.getVar3());
				if(exam10entity.getOption5().equals("2")||exam10entity.getOption5().equals("3")){
					p++;
					exam10entity.setVar3((100/5)*p);
					session.persist(exam10entity);
					exam10.setVar1(exam10entity.getVar1());
					exam10.setVar2(exam10entity.getVar2());
					exam10.setVar3(exam10entity.getVar3());
			if(exam10entity.getOption3().equals("1")||exam10entity.getOption3().equals("2")){
				p++;
				exam10entity.setVar3((100/5)*p);
				session.persist(exam10entity);
				exam10.setVar1(exam10entity.getVar1());
				exam10.setVar2(exam10entity.getVar2());
				exam10.setVar3(exam10entity.getVar3());
				exam10.setMessage("Medicine! It\'s the science and practice of diagnosis, treatment and prevention of disease.");
				return exam10;}}}}
		exam10entity.setVar3((100/5)*p);
		session.persist(exam10entity);
		exam10.setVar1(exam10entity.getVar1());
		exam10.setVar2(exam10entity.getVar2());
		exam10.setVar3(exam10entity.getVar3());
		exam10.setMessage("Can\'t find a career for you. Sorry!");
		return exam10;
	}

	@Override
	public Exam10 engineering(Exam10Entity exam10entity) {
		Exam10 exam10=new Exam10();
		int p=3;
		Session session = sessionFactory.getCurrentSession();
		if(exam10entity.getOption2().equals("2")||exam10entity.getOption2().equals("3")||exam10entity.getOption2().equals("1")){
			p++;
			exam10entity.setVar3((100/5)*p);
			session.persist(exam10entity);
			exam10.setVar1(exam10entity.getVar1());
			exam10.setVar2(exam10entity.getVar2());
			exam10.setVar3(exam10entity.getVar3());
			if(exam10entity.getOption4().equals("2")||exam10entity.getOption4().equals("1")){
				p++;
				exam10entity.setVar3((100/5)*p);
				session.persist(exam10entity);
				exam10.setVar1(exam10entity.getVar1());
				exam10.setVar2(exam10entity.getVar2());
				exam10.setVar3(exam10entity.getVar3());
				exam10.setMessage("Engineering! Application of scientific knowledge in order to invent, innovate, design and improve things.");
				return exam10;}}
		exam10entity.setVar3((100/5)*p);
		session.persist(exam10entity);
		exam10.setVar1(exam10entity.getVar1());
		exam10.setVar2(exam10entity.getVar2());
		exam10.setVar3(exam10entity.getVar3());
		exam10.setMessage("Can\'t find a career for you. Sorry!");
		return exam10;
	}

	@Override
	public Exam10 artist(Exam10Entity exam10entity) {
		Exam10 exam10=new Exam10();
		int p=3;
		Session session = sessionFactory.getCurrentSession();
		if(exam10entity.getOption2().equals("2")||exam10entity.getOption2().equals("3")){
			p++;
			exam10entity.setVar3((100/5)*p);
			session.persist(exam10entity);
			exam10.setVar1(exam10entity.getVar1());
			exam10.setVar2(exam10entity.getVar2());
			exam10.setVar3(exam10entity.getVar3());
			if(exam10entity.getOption3().equals("2")||exam10entity.getOption3().equals("3")){
				p++;
				exam10entity.setVar3((100/5)*p);
				session.persist(exam10entity);
				exam10.setVar1(exam10entity.getVar1());
				exam10.setVar2(exam10entity.getVar2());
				exam10.setVar3(exam10entity.getVar3());
				exam10.setMessage("Artist! You were born to be creative. This career has vast opportunities, including stage artists, movie actors, painters and much more!");
				return exam10;}}
		exam10entity.setVar3((100/5)*p);
		session.persist(exam10entity);
		exam10.setVar1(exam10entity.getVar1());
		exam10.setVar2(exam10entity.getVar2());
		exam10.setVar3(exam10entity.getVar3());
		exam10.setMessage("Can\'t find a career for you. Sorry!");
		return exam10;
	}
	
}