package com.infy.dao;


import com.infy.entity.Exam10Entity;
import com.infy.model.Exam10;
import com.infy.model.Login;
import com.infy.model.Profile;

public interface CareerDAO {
	
	public Login getDetails(Login login);
	public Login register(Login login);
	public Profile registerProfile(Profile profile);
	public Profile getProfile(String username);
	public Exam10 setOptions(Exam10 exam10);
	public Exam10 evaluate10(String username);
	public Exam10 evaluate12(String username);
	public Exam10 evaluateNon(String username);
	public Exam10 literature(Exam10Entity exam10entity);
	public Exam10 medicine(Exam10Entity exam10entity);
	public Exam10 engineering(Exam10Entity exam10entity);
	public Exam10 artist(Exam10Entity exam10entity);
}
