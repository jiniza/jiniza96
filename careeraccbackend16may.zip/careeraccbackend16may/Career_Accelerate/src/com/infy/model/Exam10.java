package com.infy.model;

public class Exam10 {
	private String username;
private String option1;
private String option2;
private String option3;
private String option4;
private String option5;
private String option6;
private String option7;
private String option8;
private String option9;
private String option10;
private String option11;
private String option12;
private String option13;
private String option14;
private String option15;
private String message;
private Integer var1;
private Integer var2;
private Integer var3;
public Integer getVar3() {
	return var3;
}
public void setVar3(Integer var3) {
	this.var3 = var3;
}
public Integer getVar1() {
	return var1;
}
public void setVar1(Integer var1) {
	this.var1 = var1;
}
public Integer getVar2() {
	return var2;
}
public void setVar2(Integer var2) {
	this.var2 = var2;
}
public String getOption15() {
	return option15;
}
public void setOption15(String option15) {
	this.option15 = option15;
}
public String getOption14() {
	return option14;
}
public void setOption14(String option14) {
	this.option14 = option14;
}
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getOption1() {
	return option1;
}
public void setOption1(String option1) {
	this.option1 = option1;
}
public String getOption2() {
	return option2;
}
public void setOption2(String option2) {
	this.option2 = option2;
}
public String getOption3() {
	return option3;
}
public void setOption3(String option3) {
	this.option3 = option3;
}
public String getOption4() {
	return option4;
}
public void setOption4(String option4) {
	this.option4 = option4;
}
public String getOption5() {
	return option5;
}
public void setOption5(String option5) {
	this.option5 = option5;
}
public String getOption6() {
	return option6;
}
public void setOption6(String option6) {
	this.option6 = option6;
}
public String getOption7() {
	return option7;
}
public void setOption7(String option7) {
	this.option7 = option7;
}
public String getOption8() {
	return option8;
}
public void setOption8(String option8) {
	this.option8 = option8;
}
public String getOption9() {
	return option9;
}
public void setOption9(String option9) {
	this.option9 = option9;
}
public String getOption10() {
	return option10;
}
public void setOption10(String option10) {
	this.option10 = option10;
}
public String getOption11() {
	return option11;
}
public void setOption11(String option11) {
	this.option11 = option11;
}
public String getOption12() {
	return option12;
}
public void setOption12(String option12) {
	this.option12 = option12;
}
public String getOption13() {
	return option13;
}
public void setOption13(String option13) {
	this.option13 = option13;
}
}
