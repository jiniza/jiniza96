package com.infy.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.CareerDAO;
import com.infy.model.Exam10;
import com.infy.model.Login;
import com.infy.model.Profile;
@Service("CareerService")
@Transactional(readOnly = true)
public class CareerServiceImpl implements CareerService {
	@Autowired
	private CareerDAO dao;
	
	@Transactional(readOnly = true)
	public Login getDetails(Login login) throws Exception {
		Login login1=dao.getDetails(login);
		if(login1 == null) {
			throw new Exception("Service.INVALID_USERNAME");
		}
		return login1;
	}

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Login register(Login login) throws Exception {
		Login login1=dao.register(login);
		if(login1 == null) {
			throw new Exception("Service.INVALID_USERNAME");
		}
		return login1;
	}

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Profile register(Profile profile) throws Exception {
		Profile profile1=dao.registerProfile(profile);
		if(profile1 == null) {
			throw new Exception("Service.INVALID_USERNAME");
		}
		return profile1;
	}

	@Transactional(readOnly = true)
	public Profile getProfile(String username) throws Exception {
		Profile profile=dao.getProfile(username);
		if(profile == null) {
			throw new Exception("Service.INVALID_USERNAME");
		}
		return profile;
	}

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Exam10 setOptions(Exam10 exam10) throws Exception {
		Exam10 exam1=dao.setOptions(exam10);
		if(exam1==null)
			throw new Exception("Service.INVALID_USERNAME");
		return exam1;
	}

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Exam10 evaluate10(String username) throws Exception {
		Exam10 exam1=dao.evaluate10(username);
		if(exam1==null)
			throw new Exception("Service.INVALID_USERNAME");
		return exam1;
	}
	
}