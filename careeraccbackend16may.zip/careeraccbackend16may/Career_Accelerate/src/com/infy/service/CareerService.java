package com.infy.service;

import com.infy.model.Exam10;
import com.infy.model.Login;
import com.infy.model.Profile;
public interface CareerService {

	public Login getDetails(Login login) throws Exception;
	public Login register(Login login) throws Exception;
	public Profile register(Profile profile) throws Exception;
	public Profile getProfile(String username) throws Exception;
	public Exam10 setOptions(Exam10 exam10) throws Exception;
	public Exam10 evaluate10(String username) throws Exception;
}