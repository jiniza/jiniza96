DROP TABLE Login;
DROP TABLE Profile;

create table Login(
username varchar2(15) PRIMARY KEY,
password varchar2(20) not null,
email varchar2(30) not null
);

CREATE TABLE Profile (
sId NUMBER(7),
firstName VARCHAR2(25),
lastName VARCHAR2(25),
schoolName VARCHAR2(25),
stream VARCHAR2(25),
standard VARCHAR2(25),
phoneNumber VARCHAR2(20), 
username VARCHAR2(15) REFERENCES Login(username) PRIMARY KEY
);
Drop Table Exam10;
CREATE TABLE Exam10 (
username varchar2(15) REFERENCES Login(username) PRIMARY KEY ,
option1 varchar2(30),
option2 varchar2(30),
option3 varchar2(30),
option4 varchar2(30),
option5 varchar2(30),
option6 varchar2(30),
option7 varchar2(30),
option8 varchar2(30),
option9 varchar2(30),
option10 varchar2(30),
option11 varchar2(30),
option12 varchar2(30),
option13 varchar2(30),
option14 varchar2(30),
option15 varchar2(30),
var1 number(10),
var2 number(10),
var3 number(10)
);


select * from Login;
select * from Profile;
SELECT * FROM Exam10;