package com.infy.service;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.AlgorithmDAO;
import com.infy.model.Clients;

@Service("algoService")
@Transactional(readOnly = true)
public class AlgorithmServiceImpl implements AlgorithmService{
       @Autowired
       private AlgorithmDAO algodao;
       
       public Double futureValue(Integer time,Float rate,Float compound)
       {
    	   return ((Math.pow((1+(rate/compound)),(compound*time)))-1)/(rate/compound);//      PMT � {[(1 + r/n)(nt) - 1] / (r/n)}
    	   
       }
       @Override
       public Double individualCar(Clients client,Integer time,Integer price,Float percent,Integer resale) throws Exception {
              
              Integer i2=algodao.getNetAssets(client);
              Integer i=algodao.getAnnualSavings(client)*time;
              
              System.out.println("net worth"+i2);
              System.out.println("net saving"+i);
              Integer netWorth=i+i2;
              Double arr;
              
              Integer netWorthPercent=Math.round((netWorth*percent)/100);
              System.out.println("nwp"+netWorthPercent);
              Double inflatedPrice = (1.0489*price)-resale; //inflation rate for vechicles in india is 4.89% for 2019
              
              if(inflatedPrice<=netWorthPercent)
                     return null;
              
              else
              {
                     if(netWorth>0)
                           {
                    	 inflatedPrice=inflatedPrice-netWorthPercent;
                           }
                     
                     double equityPrinciple = 0.4*inflatedPrice/futureValue(time, 0.2f, 12.0f);
                     double debtPrinciple = 0.6*inflatedPrice/futureValue(time, 0.12f, 12.0f);
                     arr= equityPrinciple+debtPrinciple;
              }
              return arr;
       }
     @Override
     public Double individualHome(Clients client, Integer time, Integer price, Float percent, Integer resale) throws Exception {
            
    	 Integer i2=algodao.getNetAssets(client);
         Integer i=algodao.getAnnualSavings(client)*time;
         
         System.out.println("net worth"+i2);
         System.out.println("net saving"+i);
         Integer netWorth=i+i2;
         Double arr;
         
         Integer netWorthPercent=Math.round((netWorth*percent)/100);
         System.out.println("nwp"+netWorthPercent);
         Double inflatedPrice = (1.057*price)-resale; //inflation rate predicted for properties in india is 5.70% for future
         
         if(inflatedPrice<=netWorthPercent)
                return null;
         
         else
         {
                if(netWorth>0)
                      {
               	 inflatedPrice=inflatedPrice-netWorthPercent;
                      }
                
                double equityPrinciple = 0.4*inflatedPrice/futureValue(time, 0.2f, 12.0f);
                double debtPrinciple = 0.6*inflatedPrice/futureValue(time, 0.12f, 12.0f);
                arr= equityPrinciple+debtPrinciple;
         }
         return arr;  
     }
     @Override
     public Double individualEdu(Clients client, Integer age, Integer fee, Float percent) throws Exception {
            

    	 Integer i2=algodao.getNetAssets(client),time=18-age;
         Integer i=algodao.getAnnualSavings(client)*time;
         
         System.out.println("net worth"+i2);
         System.out.println("net saving"+i);
         Integer netWorth=i+i2;
         Double arr;
         
         Integer netWorthPercent=Math.round((netWorth*percent)/100);
         System.out.println("nwp"+netWorthPercent);
         Double inflatedPrice = fee*(Math.pow((1+(0.05/time)),time))*4; //inflation rate predicted for college fees in india is 5.00%         
         if(inflatedPrice<=netWorthPercent)
                return null;
         
         else
         {
                if(netWorth>0)
                      {
               	 inflatedPrice=inflatedPrice-netWorthPercent;
                      }
                
                double equityPrinciple = 0.4*inflatedPrice/futureValue(time, 0.2f, 12.0f);
                double debtPrinciple = 0.6*inflatedPrice/futureValue(time, 0.12f, 12.0f);
                arr= equityPrinciple+debtPrinciple;
         }
         return arr;  
     }
     @Override
     public Double individualRetire(Clients client) throws Exception {
            

    	 
         Integer i[]=algodao.getRetireSavings(client);
         System.out.println(i[0]);
         Double arr;
         Integer age=client.getCdate().until(LocalDate.now()).getYears();
         Integer time=60-age;
         Integer retirementFund = i[0]*20; //inflation rate predicted for college fees in india is 5.00%         
         System.out.println(age);
                
                double equityPrinciple = 0.4*retirementFund/futureValue(time, 0.2f, 12.0f);
                double debtPrinciple = 0.6*retirementFund/futureValue(time, 0.12f, 12.0f);
                arr= equityPrinciple+debtPrinciple;
         
         return arr;  
     }
}

