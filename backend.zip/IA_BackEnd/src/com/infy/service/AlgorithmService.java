package com.infy.service;

import com.infy.model.Clients;

public interface AlgorithmService {
	public Double individualCar(Clients client,Integer time,Integer price,Float percent,Integer resale) throws Exception;
	public Double individualHome(Clients client,Integer time,Integer price,Float percent,Integer resale) throws Exception;
	public Double individualEdu(Clients client, Integer age, Integer fee, Float percent)
			throws Exception;
	public Double individualRetire(Clients client) throws Exception;

	
}
