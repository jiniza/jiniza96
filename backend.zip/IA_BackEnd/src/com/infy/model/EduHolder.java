package com.infy.model;

public class EduHolder {
	private Clients clients;
	private Integer age;
	private Integer fee;
	private Float percent;
	public Clients getClients() {
		return clients;
	}
	public void setClient(Clients clients) {
		this.clients = clients;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Integer getFee() {
		return fee;
	}
	public void setFee(Integer fee) {
		this.fee = fee;
	}
	public Float getPercent() {
		return percent;
	}
	public void setPercent(Float percent) {
		this.percent = percent;
	}
}
